package io.swagger.models;

public class Children {
    public String getName() {
        return null;
    }

    public void setName(String name) {
    }
}
