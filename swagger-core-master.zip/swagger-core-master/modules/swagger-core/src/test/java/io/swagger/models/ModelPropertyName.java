package io.swagger.models;

public class ModelPropertyName {
    public boolean is_persistent() {
        return true;
    }

    public String gettersAndHaters() {
        return null;
    }
}