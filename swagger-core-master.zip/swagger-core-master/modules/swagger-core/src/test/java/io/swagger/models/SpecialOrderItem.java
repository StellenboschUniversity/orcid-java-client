package io.swagger.models;

public class SpecialOrderItem {
    public String name;
    public Long id;
}