package io.swagger.filter;

import io.swagger.core.filter.AbstractSpecFilter;

/**
 * Does nothing
 **/
public class NoOpOperationsFilter extends AbstractSpecFilter {
}