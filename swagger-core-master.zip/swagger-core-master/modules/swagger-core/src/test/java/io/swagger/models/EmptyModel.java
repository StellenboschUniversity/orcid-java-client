package io.swagger.models;

public class EmptyModel {
}
