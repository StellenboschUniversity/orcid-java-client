package io.swagger.models;

import io.swagger.annotations.ApiModel;

@ApiModel("MyModel")
public class ModelWithApiModel {
    public String name;
}
