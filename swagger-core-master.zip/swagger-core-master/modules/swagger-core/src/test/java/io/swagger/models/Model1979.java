package io.swagger.models;

import io.swagger.annotations.ApiModelProperty;

public class Model1979 {
    @ApiModelProperty(allowEmptyValue = true)
    public String id;
}
