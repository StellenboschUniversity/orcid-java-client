package io.swagger.models;

public class ModelWithEnumField {
    public TestEnum enumValue;
}
