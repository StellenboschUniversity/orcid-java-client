package io.swagger.models;

public class ModelWithEnumProperty {
    private TestEnum e;

    public TestEnum getEnumValue() {
        return e;
    }

    public void setEnumValue(TestEnum e) {
        this.e = e;
    }
}
