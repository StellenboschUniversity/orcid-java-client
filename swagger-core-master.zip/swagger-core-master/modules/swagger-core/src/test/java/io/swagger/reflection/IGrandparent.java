package io.swagger.reflection;

public interface IGrandparent<T extends Number> {
    String parametrizedMethod5(T arg);
}
