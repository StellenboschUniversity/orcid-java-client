package io.swagger.model.override;

public class MyCustomClass {
    // does nothing, really
}
