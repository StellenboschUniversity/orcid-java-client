package io.swagger.models;

import io.swagger.annotations.ApiModelProperty;

public class ReadOnlyFields {
    @ApiModelProperty(readOnly = true)
    public Long id;
}
