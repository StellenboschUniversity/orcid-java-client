package io.swagger.models;

public class GenericType<T> {
    public T value;
}
