package io.swagger.resources.generics;

import java.io.Serializable;

public abstract class AbstractEntity implements Serializable {
    public String id;
}
