package io.swagger.models;

import io.swagger.annotations.ApiModel;

/**
 * <p>Provides ...</p>
 * <p>
 * <p>Created on 25/08/2016 by willows_s</p>
 *
 * @author <a href="mailto:willows_s@iblocks.co.uk">willows_s</a>
 */
@ApiModel(description = "Sub1Bean", parent = BaseBean.class)
public class Sub1Bean extends BaseBean {
    public int c;
}
