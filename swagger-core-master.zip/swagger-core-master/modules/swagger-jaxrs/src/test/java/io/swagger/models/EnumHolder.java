package io.swagger.models;

public class EnumHolder {
    private TestEnum value;

    public TestEnum getValue() {
        return value;
    }

    public void setValue(TestEnum value) {
        this.value = value;
    }
}
