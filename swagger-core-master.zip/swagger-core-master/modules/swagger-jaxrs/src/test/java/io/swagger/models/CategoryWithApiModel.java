package io.swagger.models;

import io.swagger.annotations.ApiModel;

import javax.xml.bind.annotation.XmlRootElement;

@ApiModel("MyCategory")
@XmlRootElement(name = "CategoryWithApiModel")
public class CategoryWithApiModel {
}
