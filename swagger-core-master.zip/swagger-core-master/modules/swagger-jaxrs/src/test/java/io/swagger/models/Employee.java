package io.swagger.models;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Employee")
public class Employee {
    public long id;
    public String name;
}