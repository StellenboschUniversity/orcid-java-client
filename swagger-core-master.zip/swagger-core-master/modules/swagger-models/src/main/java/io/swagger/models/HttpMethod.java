package io.swagger.models;

/**
 * Created by russellb337 on 7/10/15.
 */
public enum HttpMethod {
    POST,
    GET,
    PUT,
    PATCH,
    DELETE,
    HEAD,
    OPTIONS
}
