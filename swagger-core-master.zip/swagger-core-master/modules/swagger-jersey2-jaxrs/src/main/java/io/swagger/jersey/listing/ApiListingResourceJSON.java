package io.swagger.jersey.listing;

import io.swagger.jaxrs.listing.ApiListingResource;

@Deprecated
public class ApiListingResourceJSON
        extends ApiListingResource {
}