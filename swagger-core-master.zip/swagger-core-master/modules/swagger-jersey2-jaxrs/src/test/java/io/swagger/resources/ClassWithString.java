package io.swagger.resources;

public class ClassWithString {
    public String value;
}
