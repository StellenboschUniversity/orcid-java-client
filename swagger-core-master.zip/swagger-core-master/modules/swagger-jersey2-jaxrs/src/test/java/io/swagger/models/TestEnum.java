package io.swagger.models;

public enum TestEnum {
    ONE, TWO, THREE;
}
